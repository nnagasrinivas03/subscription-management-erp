import mongoose from "mongoose";

export default mongoose.model("Payment", new mongoose.Schema({
  invoice: { type: mongoose.Schema.Types.ObjectId, ref: "Invoice" },
  amount: Number,
  method: String,
  date: { type: Date, default: Date.now }
}));
