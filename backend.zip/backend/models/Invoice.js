import mongoose from "mongoose";

export default mongoose.model("Invoice", new mongoose.Schema({
  subscription: { type: mongoose.Schema.Types.ObjectId, ref: "Subscription" },
  total: Number,
  status: { type: String, default: "Draft" },
  dueDate: Date
}));
