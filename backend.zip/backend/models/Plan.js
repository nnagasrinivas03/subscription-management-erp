import mongoose from "mongoose";

export default mongoose.model("Plan", new mongoose.Schema({
  name: String,
  price: Number,
  billingPeriod: String,
  minQty: Number,
  startDate: Date,
  endDate: Date
}));
