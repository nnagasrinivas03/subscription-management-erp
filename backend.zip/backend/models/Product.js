import mongoose from "mongoose";

export default mongoose.model("Product", new mongoose.Schema({
  name: String,
  type: String,
  salesPrice: Number,
  costPrice: Number
}));
