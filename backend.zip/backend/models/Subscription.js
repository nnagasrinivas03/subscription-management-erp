import mongoose from "mongoose";

export default mongoose.model("Subscription", new mongoose.Schema({
  customer: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  plan: { type: mongoose.Schema.Types.ObjectId, ref: "Plan" },
  startDate: Date,
  endDate: Date,
  status: { type: String, default: "Active" }
}));
