import express from "express";
import Plan from "../models/Plan.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();
router.post("/", protect, async(req,res)=>res.json(await Plan.create(req.body)));
router.get("/", protect, async(req,res)=>res.json(await Plan.find()));
export default router;
