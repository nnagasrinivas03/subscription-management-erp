import express from "express";
import Invoice from "../models/Invoice.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();
router.post("/", protect, async(req,res)=>res.json(await Invoice.create(req.body)));
router.get("/", protect, async(req,res)=>res.json(await Invoice.find().populate("subscription")));
export default router;
