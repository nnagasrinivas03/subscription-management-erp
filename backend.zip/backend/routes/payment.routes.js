import express from "express";
import Payment from "../models/Payment.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();
router.post("/", protect, async(req,res)=>res.json(await Payment.create(req.body)));
router.get("/", protect, async(req,res)=>res.json(await Payment.find().populate("invoice")));
export default router;
