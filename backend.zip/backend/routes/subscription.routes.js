import express from "express";
import Subscription from "../models/Subscription.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();
router.post("/", protect, async(req,res)=>res.json(await Subscription.create(req.body)));
router.get("/", protect, async(req,res)=>res.json(await Subscription.find().populate("customer plan")));
export default router;
