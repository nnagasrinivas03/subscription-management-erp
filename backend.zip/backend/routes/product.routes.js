import express from "express";
import Product from "../models/Product.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();

router.post("/", protect, async(req,res)=>res.json(await Product.create(req.body)));
router.get("/", protect, async(req,res)=>res.json(await Product.find()));
router.put("/:id", protect, async(req,res)=>res.json(await Product.findByIdAndUpdate(req.params.id,req.body,{new:true})));
router.delete("/:id", protect, async(req,res)=>res.json(await Product.findByIdAndDelete(req.params.id)));

export default router;
